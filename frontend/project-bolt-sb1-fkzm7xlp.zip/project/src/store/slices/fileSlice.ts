import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axios from 'axios';
import { File, ShareLink } from '../../types';

const API_URL = 'http://127.0.0.1:8000/api';

export const uploadFile = createAsyncThunk(
  'files/upload',
  async (file: File, { getState }: any) => {
    const { auth } = getState();
    const formData = new FormData();
    formData.append('file', file);

    const response = await axios.post(`${API_URL}/files/upload/`, formData, {
      headers: {
        Authorization: `Bearer ${auth.token}`,
        'Content-Type': 'multipart/form-data',
      },
    });
    return response.data;
  }
);

export const listFiles = createAsyncThunk(
  'files/list',
  async (_, { getState }: any) => {
    const { auth } = getState();
    const response = await axios.get(`${API_URL}/files/files/`, {
      headers: { Authorization: `Bearer ${auth.token}` },
    });
    return response.data;
  }
);

export const shareFile = createAsyncThunk(
  'files/share',
  async (
    {
      fileId,
      userId,
      permission,
      expiresAt,
    }: {
      fileId: string;
      userId: number;
      permission: string;
      expiresAt: string;
    },
    { getState }: any
  ) => {
    const { auth } = getState();
    const response = await axios.post(
      `${API_URL}/files/files/${fileId}/share/`,
      {
        shared_with: userId,
        permission,
        expires_at: expiresAt,
      },
      {
        headers: { Authorization: `Bearer ${auth.token}` },
      }
    );
    return response.data;
  }
);

export const generateShareableLink = createAsyncThunk(
  'files/generateLink',
  async (
    {
      fileId,
      expiresAt,
      oneTimeUse,
    }: {
      fileId: string;
      expiresAt: string;
      oneTimeUse: boolean;
    },
    { getState }: any
  ) => {
    const { auth } = getState();
    const response = await axios.post(
      `${API_URL}/files/files/${fileId}/generate-link/`,
      {
        expires_at: expiresAt,
        one_time_use: oneTimeUse,
      },
      {
        headers: { Authorization: `Bearer ${auth.token}` },
      }
    );
    return response.data;
  }
);

interface FileState {
  files: File[];
  shareLinks: ShareLink[];
  loading: boolean;
  error: string | null;
}

const initialState: FileState = {
  files: [],
  shareLinks: [],
  loading: false,
  error: null,
};

const fileSlice = createSlice({
  name: 'files',
  initialState,
  reducers: {
    clearFileError: (state) => {
      state.error = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(uploadFile.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(uploadFile.fulfilled, (state, action) => {
        state.loading = false;
        state.files.push(action.payload);
      })
      .addCase(uploadFile.rejected, (state, action) => {
        state.loading = false;
        state.error = action.error.message || 'Upload failed';
      })
      .addCase(listFiles.fulfilled, (state, action) => {
        state.files = action.payload;
      })
      .addCase(generateShareableLink.fulfilled, (state, action) => {
        state.shareLinks.push(action.payload);
      });
  },
});

export const { clearFileError } = fileSlice.actions;
export default fileSlice.reducer;