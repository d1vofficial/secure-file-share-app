export interface User {
  id: number;
  username: string;
  email: string;
  mfa_enabled: boolean;
}

export interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  loading: boolean;
  error: string | null;
  mfaRequired: boolean;
  mfaSetupData: {
    qrCode?: string;
    secret?: string;
  } | null;
}

export interface File {
  id: string;
  name: string;
  size: number;
  uploaded_at: string;
  owner: number;
  shared_with: number[];
}

export interface ShareLink {
  id: string;
  file: string;
  expires_at: string;
  one_time_use: boolean;
  url: string;
}